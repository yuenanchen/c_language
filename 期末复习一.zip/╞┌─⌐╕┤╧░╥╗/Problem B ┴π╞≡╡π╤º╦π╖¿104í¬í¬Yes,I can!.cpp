#include<stdio.h>

int main()
{
	char a[9];
	while(gets(a)!=NULL)
	{
		printf("I am ");                                                                                                                                                               
		printf("%s,yes,I can!",a);
	}
	return 0;
}
