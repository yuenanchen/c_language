#include<stdio.h>
int main()
{
	int f[100],i,n;
	f[1]=1;
	f[0]=1;
	for(i=2;i<1000;i++)
	{
		f[i]=f[i-1]+f[i-2];	
	}
	scanf("%d",&n);
	for(i=0;i<n-1;i++)
		printf("%d ",f[i]);
	printf("%d\n",f[n-1]);
	return 0;
}
